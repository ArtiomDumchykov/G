

let project_folder = require("path").basename(__dirname);
let source_folder = "#src";

let fs = require("fs");

let path = {
    build:{
        html: project_folder + "/",
        css: project_folder + "/css/",
        js: project_folder + "/js/",
        img: project_folder + "/img/",
        fonts: project_folder + "/fonts/",
        audio: project_folder + "/audio/",
        video: project_folder + "/video/",

    },
    src:{
        html: [source_folder + "/*.html", "!" + source_folder + "/_*.html"],
        css: [source_folder + "/scss/*.scss", "!"+ source_folder + "/scss/fonts.scss" ],
        // css: source_folder + "/scss/style.scss",
        css2: source_folder + "/scss/**/*.css",
        js: source_folder + "/js/main.js",
        js2: [source_folder+ "/js/*.js", "!"+ source_folder + "/js/main.js", "!"+ source_folder + "/js/testWebP.js"],
        img: source_folder + "/img/**/*.{jpg, png, svg, gif, ico, webp}",
        audio: source_folder + "/audio/*.{mp3, ogg, wma, m4a, wav}",
		video: source_folder + "/video/*.{mp4, m4v, webm, ogv, wmv, flv}",
        fonts: source_folder + "/fonts/**/*.ttf",

    },
    watch:{
        html: source_folder + "/**/*.html",
        css: source_folder + "/scss/**/*.scss",
        js: source_folder + "/js/**/*.js",
        img: source_folder + "/img/**/*.{jpg, png, svg, gif, ico, webp}",
        audio: source_folder + "/audio/**/*.{mp3, ogg, wma, m4a, wav}",
		video: source_folder + "/video/**/*.{mp4, m4v, webm, ogv, wmv, flv}",

    },
    clean: "./" + project_folder + "/"

}

let {src, dest} = require("gulp"),
    gulp = require("gulp"),
    browsersync = require("browser-sync").create(),
    fileinclude = require ("gulp-file-include"),
    del = require ("del"),
    scss =  require('gulp-sass')(require('sass')),
    autoprefixer = require ("gulp-autoprefixer"),
    group_media = require("gulp-group-css-media-queries"),
    clean_css = require ("gulp-clean-css"),
    rename = require ("gulp-rename"),
    uglify_es = require("gulp-uglify-es").default,
    babel = require("gulp-babel"),
    imagemin = require("gulp-imagemin"),
    webp = require("gulp-webp"), //npm i webp-converter@2.2.3 --save-exact / npm i webp-converter@2.2.3 --save-dev
    webphtml = require("gulp-webp-html"),
    webpcss = require("gulp-webpcss"),
    webpconvert =require('webp-converter'),
    svgSprite = require("gulp-svg-sprite"),
    ttf2woff = require('gulp-ttf2woff'),
    ttf2woff2 = require('gulp-ttf2woff2'),
    fonter = require('gulp-fonter'),
    htmlmin = require('gulp-htmlmin');



   function browserSync(params) {
       browsersync.init({
           server: {
               baseDir: "./" + project_folder + "/",
           },
           port:3000,
           notify: false
       })
   } 
function html() {
    return src(path.src.html)
        .pipe(fileinclude())
        .pipe(
            webphtml()
        )
        .pipe(dest(path.build.html))
        .pipe(
            webphtml()
        )
        .pipe(htmlmin({ collapseWhitespace: true }))
        .pipe(
            rename({
                extname: ".min.html"
            })
        )
        .pipe(dest(path.build.html))
        .pipe(browsersync.stream())

}

function audio() {
	return src(path.src.audio)
	    .pipe(dest(path.build.audio))
}
function video() {
	return src(path.src.video)
	    .pipe(dest(path.build.video))
}

function fonts() {
	src(path.src.fonts)
		.pipe(ttf2woff())
		.pipe(dest(path.build.fonts));
	return src(path.src.fonts)
		.pipe(ttf2woff2())
		.pipe(dest(path.build.fonts));
};

function images() {
    return src(path.src.img)
    .pipe(
        webp({
            quality: 70
        })
    )
    .pipe(dest(path.build.img))
    .pipe(src(path.src.img))
    .pipe(
        imagemin({
            progressive: true,
            svgPlugins:[{removeViewBox: false}],
            interlaced: true,
            optimizationLevel:3
        })
    )
    .pipe(dest(path.build.img))
    .pipe(browsersync.stream())

}
function css() {
    return src(path.src.css)
        .pipe(
            scss({
                 outputStyle: 'expanded'
                }).on('error', scss.logError)
        )
        .pipe(
            group_media()
        )
        .pipe(
            autoprefixer({
                overrideBrowserslist: ["last 5 versions"],
                cascade: true
            })
        )
        .pipe(
            webpcss({ webpClass: '.webp', noWebpClass: '.no-webp' })
        )
        .pipe(dest(path.build.css))
        .pipe (
            clean_css()
        )
        .pipe(
            rename({
                extname: ".min.css"
            })
        )
        .pipe(dest(path.build.css))
        .pipe(browsersync.stream())

}
function css2() {
    return src(path.src.css2)
        .pipe(dest(path.build.css))
        // .pipe(browsersync.stream())

}

function js() {
    return src(path.src.js)
        .pipe(fileinclude())
        .pipe(dest(path.build.js))
        .pipe(
            uglify_es()
        )
        .pipe(
            rename({
                extname: ".min.js"
            })
        )
        .pipe(gulp.dest(project_folder + "/js"))
        .pipe(babel({
                presets: ["@babel/preset-env"]
        }))
        .pipe(
            rename(
                "main_babel.js"
            )
        )
        .pipe(gulp.dest(project_folder + "/js"))  
        .pipe(
            uglify_es()
        )
        .pipe(
            rename({
                extname: ".min.js"
            })
        )
        .pipe(gulp.dest(project_folder + "/js")) 
        .pipe(dest(path.build.js))
        .pipe(browsersync.stream())

}
function js2() {
    return src(path.src.js2)
        .pipe(dest(path.build.js))
        //.pipe(browsersync.stream())

}

gulp.task("otf2ttf", function () {
    return qulp.src([source_folder + "/fonts/*otf"])
    .pipe(fonter({
        formats: ['ttf']
      }))
      .pipe(dest(source_folder + "/fonts/"));
})

gulp.task("svgSprite", function () {
    return qulp.src([source_folder + "/iconsprite/*.svg"])
        .pipe(
            svgSprite({
                mode:{
                    stack: {
                        sprite: "../icons/icons.svg",
                    }
                },
            })
        )
        .pipe(dest(path.build.img))
})

const w = function () {
    fs.writeFile(source_folder + '/scss/fonts.scss', '', cb);
    return fs.readdir(path.build.fonts, function (err, items) {
        if (items) {
            let c_fontname;
            for (var i = 0; i < items.length; i++) {
                let fontname = items[i].split('.');
                fontname = fontname[0];
                if (c_fontname != fontname) {
                    fs.appendFile(source_folder + '/scss/fonts.scss', '@include font("' + fontname + '", "' + fontname + '", "400", "normal");\r\n', cb);
                }
                c_fontname = fontname;
            }
        }
    })
}

function fontsStyle() {
    let file_content = fs.readFileSync(source_folder + '/scss/fonts.scss');
    //дописать
    if (file_content != ""){
        
        w();
    }
	else if (file_content == '') {
         w();
	}
}

function cb() {

}

function watchFiles() {
    gulp.watch([path.watch.html], html);
    gulp.watch([path.watch.css], css);
    gulp.watch([path.watch.js], js);
    gulp.watch([path.watch.img], images);
    gulp.watch([path.watch.audio], audio);
	gulp.watch([path.watch.video], video);
   
}
function clean(params) {
    return del(path.clean);
}

let build = gulp.series(clean, gulp.parallel(js,js2,css,css2,html, images, audio, video, fonts), fontsStyle);
let watch = gulp.parallel(build, watchFiles,browserSync);

exports.fontsStyle = fontsStyle;
exports.audio = audio;
exports.video = video;
exports.fonts = fonts;
exports.images = images;
exports.js = js;
exports.js2 = js2;
exports.css = css;
exports.css2 = css2;
exports.html = html;
exports.build = build;
exports.watch = watch;
exports.default = watch;